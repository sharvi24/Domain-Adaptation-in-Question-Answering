# PrimeQA MRC Notebooks

Here you will find notebooks for running PrimeQA's MRC interactively.  Make sure to install the `notebooks` extras before running.
