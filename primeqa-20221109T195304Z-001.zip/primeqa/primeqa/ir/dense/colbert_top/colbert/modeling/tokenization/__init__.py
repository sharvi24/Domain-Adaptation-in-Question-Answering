from primeqa.ir.dense.colbert_top.colbert.modeling.tokenization.query_tokenization import *
from primeqa.ir.dense.colbert_top.colbert.modeling.tokenization.doc_tokenization import *
from primeqa.ir.dense.colbert_top.colbert.modeling.tokenization.utils import tensorize_triples
